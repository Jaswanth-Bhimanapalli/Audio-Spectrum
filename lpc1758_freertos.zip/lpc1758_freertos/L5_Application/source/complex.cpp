/*
 * complex.cpp
 *
 *  Created on: Apr 17, 2016
 *      Author: Ramanand
 */
//   Include header file
#include <source/complex.h>

//   Imaginary unity constants
const complex complex::i(0., 1.);
const complex complex::j(0., 1.);




