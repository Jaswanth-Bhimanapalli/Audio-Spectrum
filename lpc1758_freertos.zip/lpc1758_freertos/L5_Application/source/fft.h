/*
 * fft.h
 *
 *  Created on: Apr 17, 2016
 *      Author: Ramanand
 */

#ifndef FFT_H_
#define FFT_H_
//   Include complex numbers header
#include <source/complex.h>

class CFFT
{
public:
    //   FORWARD FOURIER TRANSFORM
    //     Input  - input data
    //     Output - transform result
    //     N      - length of both input data and result
    //static bool Forward(const complex *const Input, complex *const Output, const unsigned int N);

    //   FORWARD FOURIER TRANSFORM, INPLACE VERSION
    //     Data - both input data and output
    //     N    - length of input data
    //static bool Forward(complex *const Data, const unsigned int N);
    static complex* Forward(complex *const Data, const unsigned int N);

    //   INVERSE FOURIER TRANSFORM
    //     Input  - input data
    //     Output - transform result
    //     N      - length of both input data and result
    //     Scale  - if to scale result
    //static bool Inverse(const complex *const Input, complex *const Output, const unsigned int N, const bool Scale = true);

    //   INVERSE FOURIER TRANSFORM, INPLACE VERSION
    //     Data  - both input data and output
    //     N     - length of both input data and result
    //     Scale - if to scale result
    //static bool Inverse(complex *const Data, const unsigned int N, const bool Scale = true);

protected:
    //   Rearrange function and its inplace version
    //static void Rearrange(const complex *const Input, complex *const Output, const unsigned int N);
    static void Rearrange(complex *const Data, const unsigned int N);

    //   FFT implementation
    static complex* Perform(complex *const Data, const unsigned int N, const bool Inverse = false);

    //   Scaling of inverse FFT result
    static void Scale(complex *const Data, const unsigned int N);
};

#endif /* FFT_H_ */
