/*
 * LEDMatrix.cpp
 *
 *  Created on: May 13, 2016
 *      Author: Sucharitha
 */
#include "LEDMatrix.hpp"
#include<i2c2.hpp>
I2C2& i2cLED = I2C2::getInstance();
void displayLED(int count ,double value)
{
  //DisplayLEDZero();
  uint8_t redrow=count*2-1;
  uint8_t grow=count*2-2;
  //DisplayLEDZero();
      if(value <= 512.0)
     {
         i2cLED.writeReg(0xE0,redrow,0x00);
         i2cLED.writeReg(0xE0,grow,0x01);
     }else if((value > 512.0 ) & (value <=1024.0) )
     {
         i2cLED.writeReg(0xE0,redrow,0x00);
                i2cLED.writeReg(0xE0,grow,0x03);
         //write logic here to make other values zero

     }else if((value > 1024.0) & (value <=1536.0))
       {
         i2cLED.writeReg(0xE0,redrow,0x00);
                       i2cLED.writeReg(0xE0,grow,0x07);

              //write logic here to make other values zero

     }else if((value > 1536.0) & (value <=2048.0))
     {
         i2cLED.writeReg(0xE0,redrow,0x08);
         i2cLED.writeReg(0xE0,grow,0x0f);
            //write logic here to make other values zero
     }else if((value > 2048.0) & (value <=2560.0))
     {
         i2cLED.writeReg(0xE0,redrow,0x18);
               i2cLED.writeReg(0xE0,grow,0x1f);
            //write logic here to make other values zero
   }
     else if((value > 2560.0) & (value <=3072.0))
        {
         i2cLED.writeReg(0xE0,redrow,0x38);
                      i2cLED.writeReg(0xE0,grow,0x1f);
               //write logic here to make other values zero
      }else if((value > 3072.0) & (value <=3584.0))
      {
          i2cLED.writeReg(0xE0,redrow,0x78);
                       i2cLED.writeReg(0xE0,grow,0x1f);
             //write logic here to make other values zero
    }else if((value > 3584.0) & (value <=4096.0))
          {
        i2cLED.writeReg(0xE0,redrow,0xf8);
        i2cLED.writeReg(0xE0,grow,0x1f);

                 //write logic here to make other values zero
        }

}
void DisplayLEDZero()
{
  uint8_t ledoff=0x00;
  for(int makeoff=0;makeoff<16;makeoff++)
  {
   i2cLED.writeReg(0xE0,makeoff,ledoff);
  }

}
void i2cLEDinit()
{
    i2cLED.writeReg(0xE0,0x21,0x00);
    i2cLED.writeReg(0xE0,0xA0,0x00);
    i2cLED.writeReg(0xE0,0x81,0x00);

}





