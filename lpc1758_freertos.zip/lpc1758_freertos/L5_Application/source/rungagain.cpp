/*
 * rungagain.cpp
 *
 *  Created on: May 5, 2016
 *      Author: Ramanand
 */
#include<stdio.h>
#include<LPC17xx.h>
#include<scheduler_task.hpp>
#include<tasks.hpp>
#include "fft.h"
#include<math.h>
#include<printf_lib.h>
using namespace std;
QueueHandle_t my_adc_queue;
complex *saveSample = new complex[8];
SemaphoreHandle_t semaphore;

void timer_adc_initiate_wei()
{
        //printf("Timer Initialized");
        //configure Timer for Adc sampling
       lpc_pconp(pconp_timer3,true); //Timer enable
        lpc_pclk(pclk_timer3,clkdiv_1); //CCLK/1
        LPC_TIM3->TCR =0x2; //Timer in reset mode
        LPC_TIM3->CTCR=0x0;  //Timer mode
        LPC_TIM3->PR=8 * 1024 ;//Timer set at 44Khz
        LPC_TIM3->MCR =(1<<4);
        LPC_TIM3->MR1=1;   //Match the count with time count
        LPC_TIM3->EMR=(3<<6); //generates rising edge on MAT1.1

        //configure ADC to sample on timer
        // Enable power/clock
        LPC_SC->PCONP &=~ (1 << 12);      //Enable PCADC power/clock
        LPC_SC->PCONP |=(1 << 12);
        LPC_SC->PCLKSEL0 &= ~((1 << 24)|(1<<25)); // Clear clock Bits, PCLK_Peripheral for ADC CLK / 4  = 12Mhz

        //Configure the pin mode to be AD0.1
        LPC_PINCON->PINSEL3 &= ~(3 << 30);   //Clear P1.31 to be 00
        LPC_PINCON->PINSEL3 |= (3 << 30);   //set the pin P0.26 to ADC mode (AD0.3)

        // Configure the ADC in the A/D Control Register(ADCR)
        LPC_ADC->ADCR &=~(1<<3);
        LPC_ADC->ADCR |=(1<<3);         //select channel 1 (AD0.1)
        LPC_ADC->ADCR |= (3<< 8);  //clock divider set to 1
        LPC_ADC->ADCR &=~(1<<16);       //software controlled conversions, require 65 clocks. ???
        LPC_ADC->ADCR &=~ (1 << 21);
        LPC_ADC->ADCR &=~(1<<27);       //ADC samples on rising edge of MAT1.1 signal
        LPC_ADC->ADCR &=~(4<<24);
        LPC_ADC->ADCR |=(4<<24);        //starts ADC conversion on rising edge of MAT1.1 signal ???
        LPC_ADC->ADCR |= (1 << 21);      // Enable ADC, make it operational
        LPC_ADC->ADINTEN |=(1<<3);      //enabling ADC interrupt on completion of conversion on channel 3
        NVIC_EnableIRQ(ADC_IRQn);       //enabling the nested interrupt
        LPC_TIM3->TCR = 0x01;//start the timer
}

void ADC_IRQHandler()
{
            uint32_t adcresult=0;
            BaseType_t switch_required = 0;
//           u0_dbg_put("In IRQ handler\n");
           adcresult = (LPC_ADC->ADGDR >> 4) & 0xFFFF;
             //u0_dbg_put("collect result\n");
                 xQueueSendFromISR(my_adc_queue, &adcresult,&switch_required);
                 portEND_SWITCHING_ISR(switch_required);

}

void manipulateADCdata(void *ptr)
{
    static int samplenumber=0;
    uint32_t result;
       while(1)
       {
           xQueueReceive(my_adc_queue, &result, portMAX_DELAY);
           u0_dbg_printf("collect result ");
           //pSignal[samplenumber]=result;
           while(samplenumber<8)
           {
               saveSample[samplenumber]=result;
               samplenumber++;
                    //portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
           }
           samplenumber=0;
           xSemaphoreGive(semaphore);

       }
}
void callingFFT(void *ptr)
{
    double sqr1,sqr2;
    complex *fftout=new complex[8];
    CFFT myfft;
    while(1)
        {
            xSemaphoreTake(semaphore,portMAX_DELAY);
            fftout=myfft.Forward(saveSample,8);
            for(int s=0;s<8;s++)
            {
               // printf("retrun from FFT:%f +j %f\n",fftout[s].re(),fftout[s].im());
                sqr1=pow(fftout[s].re(),2);
                sqr2=pow(fftout[s].im(),2);
                //sqrt(sqr1+sqr2);
                printf("Square root:%f \n",sqrt(sqr1+sqr2));

            }

        }
    //NVIC_EnableIRQ(ADC_IRQn);

}
int main____runagain()
{
    vSemaphoreCreateBinary(semaphore);
    my_adc_queue=xQueueCreate(1, sizeof(uint32_t));
    printf("MAIN  \n");
    timer_adc_initiate_wei();
    xTaskCreate(callingFFT,(const char*)"TaskFFT",STACK_BYTES(2048),NULL,PRIORITY_MEDIUM,NULL);
    xTaskCreate(manipulateADCdata,(const char*)"manipulatedata",STACK_BYTES(2048),NULL,PRIORITY_HIGH,NULL);
    vTaskStartScheduler();

//    NVIC_EnableIRQ(ADC_IRQn);
    //LPC_TIM0->TCR = 1;//start the timer

    /*double sqr1,sqr2;
    CFFT myfft;
    complex *pSignal = new complex[16];
    complex *fftout = new complex[16];
    pSignal[0]=80;
    pSignal[1]=22;
    pSignal[2]=20;
    pSignal[3]=3;
    pSignal[4]=12;
    pSignal[5]=120;
    pSignal[6]=255;
    pSignal[7]=1;
    pSignal[8]=80;
    pSignal[9]=22;
    pSignal[10]=20;
    pSignal[11]=3;
    pSignal[12]=12;
    pSignal[13]=120;
    pSignal[14]=255;
    pSignal[15]=1;
    fftout=myfft.Forward(pSignal,16);
    for(int s=0;s<16;s++)
    {
        printf("retrun from FFT:%f +j %f\n",fftout[s].re(),fftout[s].im());
        sqr1=pow(fftout[s].re(),2);
        sqr2=pow(fftout[s].im(),2);
                //sqrt(sqr1+sqr2);
        printf("Square root:%f \n",sqrt(sqr1+sqr2));

    }


*/

return 0;
}










