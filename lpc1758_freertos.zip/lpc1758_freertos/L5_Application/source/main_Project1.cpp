/*
 * main_Project1.cpp
 *
 *  Created on: May 5, 2016
 *      Author: Ramanand
 */
#include<stdio.h>
#include<iostream>
#include<scheduler_task.hpp>
#include<io.hpp>
#include<LPC17xx.h>
#include<storage.hpp>
#include<lpc_sys.h>
#include<event_groups.h>
#include<soft_timer.hpp>
#include<tasks.hpp>
#include<rtc.h>
#include"adc0.h"
#include"complex.h"
#include"fft.h"
#include<math.h>
#include "LEDMatrix.hpp"
#include "commonvariables.hpp"
//SemaphoreHandle_t fftsem;
//complex *result=new complex[128];
//uint32_t arr[16];

using namespace std;
/*void myADCtimer()
{
    lpc_pconp(pconp_timer3,true); //Timer enable
        lpc_pclk(pclk_timer3,clkdiv_1); //CCLK/1
        LPC_TIM3->TCR =0x2; //Timer in reset mode
        LPC_TIM3->CTCR=0x0;  //Timer mode
        LPC_TIM3->PR=8 * 1024; //Timer set at 44Khz
        LPC_TIM3->MCR =(1<<4);
        LPC_TIM3->MR1=1;   //Match the count with time count
        LPC_TIM3->EMR=(3<<6); //generates rising edge on MAT1.1

}
class adc_h : public scheduler_task
{

    public:
        adc_h(uint8_t priority):
            scheduler_task("ADC",2048,priority)
    {


    }
        bool init()
        {
            i2cLEDinit();
            DisplayLEDZero();
            LPC_PINCON->PINSEL1 &= ~(3 << 20);   //Clear P0.26 to be 00
            LPC_PINCON->PINSEL1 |= (1 << 20);   //set the pin P0.26 to ADC mode (AD0.3)
            myADCtimer();
            adc0_init();
            LPC_TIM3->TCR = 0x01;//start the timer

            return true;
        }
        bool run(void *p)
               {
                   uint8_t snumber=0;
                   uint16_t total_samples=128;
                   //uint32_t arr[16];

                   while(snumber < total_samples)
                   {
                       result[snumber]=adc0_get_reading(3);  ///channel 3
                      // printf("result=%f\n",result[snumber].re());
                       snumber++;

                   }
                   snumber=0;
                xSemaphoreGive(fftsem);

                   return true;
               }
};

void callingFFT1(void *ptr)
{
    printf("callingFFT");
    double sqr1,sqr2,sum=0;
    int k,count=0;
    CFFT myfft;
    complex *fftout;
    while(xSemaphoreTake(fftsem,portMAX_DELAY))
        {
            fftout=myfft.Forward(result,128);
            for(int s=1;s<65;)
            {
                for(k=0;k<8;k++)
                {
                    sqr1=pow(fftout[s].re(),2);
                    sqr2=pow(fftout[s].im(),2);
                    sum=sum + sqrt(sqr1+sqr2);
                    s++;
                }
                if(k==8)
                {
                    k=0;
                    count++;
                   // printf("count :: %d sum: %f \n",count,sum/128);
                    displayLED(count ,sum/64);

                    sum=0;
                }
               // printf("Square root:%f \n",sqrt(sqr1+sqr2));
                //printf("retrun from FFT:%f +j %f\n",fftout[s].re(),fftout[s].im());
                //vTaskDelay(20);
            }
            count=0;
        }
} */
int main()
{   vSemaphoreCreateBinary(fftsem);
    scheduler_add_task(new adc_h(PRIORITY_MEDIUM));
    xTaskCreate(callingFFT1,(const char*)"Task",STACK_BYTES(4096),NULL,PRIORITY_HIGH,NULL);
    scheduler_start();
   /* scheduler_add_task(new terminalTask(PRIORITY_MEDIUM));
    scheduler_start();*/
    return true;
}




