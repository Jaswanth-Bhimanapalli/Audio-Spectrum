/*
 * semaphoretask.cpp
 *
 *  Created on: Mar 31, 2016
 *      Author: Ramanand
 */
#include<eint.h>
#include<uart0_min.h>
#include<tasks.hpp>
#include<semphr.h>
#include<LPC17xx.h>
#include<soft_timer.hpp>
#include<utilities.h>
#include"portable.h"
#include<lpc_sys.h>
#include "../freertos_timer.hpp"



SemaphoreHandle_t switchSemaphore1;
SoftTimer timervalue(50);
bool flag=true;
void ongpioPort2interrupt1(void){
       // long yield = 0;
    if(flag)
    {
        flag=false;
        timervalue.reset();
        while(!timervalue.expired());
        xSemaphoreGiveFromISR(switchSemaphore1,NULL);
    }

}
void takesemaphore1(void *p)
{
    while(1)
    {
      if (xSemaphoreTake(switchSemaphore1,portMAX_DELAY)) {
          uart0_puts("Semaphore taken");
              flag=true;

         }
    }
}

int main2ndmethod()
{
    uint8_t pinNum=6;
    vSemaphoreCreateBinary(switchSemaphore1);
    eint3_enable_port2(pinNum,eint_rising_edge,ongpioPort2interrupt1);
    xTaskCreate(takesemaphore1,(const char*)"smephoreTask", 2000, NULL,PRIORITY_LOW, NULL);
    vTaskStartScheduler();

  return 0;
}
