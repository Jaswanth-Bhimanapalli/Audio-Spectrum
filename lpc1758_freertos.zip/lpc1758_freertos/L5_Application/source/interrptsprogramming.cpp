/*
 * ApplicationProgramming.cpp
 *
 *  Created on: Apr 7, 2016
 *      Author: Ramanand
 */
#include<stdio.h>
#include<iostream>
#include<scheduler_task.hpp>
//#include<light_sensor.hpp>
#include<io.hpp>
#include<LPC17xx.h>
#include<storage.hpp>
#include<lpc_sys.h>
#include<event_groups.h>
#include<soft_timer.hpp>
#include<command_handler.hpp>
#include<handlers.hpp>
#include<tasks.hpp>
#define BIT0 (1<<0)
#define BIT1 (1<<1)
typedef enum {
   shared_LightsensorQueueId,
} sharedHandleId_t;
EventGroupHandle_t myeventgroup;
EventBits_t uxBits;
SoftTimer timervaluewatchdog(1000),cpuUsageinfo(6000);

class lightsensorproducer : public scheduler_task
{

    public:
        lightsensorproducer(uint8_t priority):
            scheduler_task("producer",2048,priority)
    {


    }
    bool init(void)
    {
        QueueHandle_t lightqueue = xQueueCreate(1,sizeof(uint16_t));
        addSharedObject(shared_LightsensorQueueId,lightqueue);
        return true;
    }
    bool run(void *p)
    {
        uint16_t collect100values[100]={0};
        uint16_t averagesensorvalue=0;
        uint16_t avg=0;
        for(int i=0;i<100;i++)
        {
            collect100values[i]=LS.getRawValue();
            averagesensorvalue=averagesensorvalue+collect100values[i];
            vTaskDelay(1);
        }
        avg=averagesensorvalue/100;

        if(myeventgroup!=NULL)
        {

          uxBits = xEventGroupSetBits(myeventgroup,BIT0);
        }
        xQueueSend(getSharedObject(shared_LightsensorQueueId), &avg, portMAX_DELAY);

        return true;
    }

};
class lightsensorconsumer : public scheduler_task
{

    public:
        lightsensorconsumer(uint8_t priority):
            scheduler_task("consumer",2048,priority)
    {


    }
        bool init()
        {

            return true;
        }
        bool run(void *p)
               {
                   //FIL fp;
                   //FRESULT fileres;
                   uint16_t getaverage;
                   uint16_t recivedtime;
                   //uint16_t data[16]={0};
                   QueueHandle_t qid = getSharedObject(shared_LightsensorQueueId);

                   if (xQueueReceive(qid, &getaverage, portMAX_DELAY))
                   {
                       recivedtime=sys_get_uptime_ms();
                      // fileres=f_open(&fp,"storage.txt",FA_WRITE|FA_OPEN_ALWAYS);
                       Storage::append("1:storage.txt", &getaverage, 4, 0);
                       Storage::append("1:storage.txt",&recivedtime , 4, 0);
                       //Storage::read()

                   }
                   if(myeventgroup!=NULL)
                    {

                      uxBits = xEventGroupSetBits(myeventgroup,BIT1);
                    }


                   return true;
               }


};
class lightwatchdog : public scheduler_task
{

    public:
        lightwatchdog(uint8_t priority):
            scheduler_task("watchlightsensor",2048,priority)
    {


    }
        bool init()
        {

            return true;
        }
        bool run(void *p)
        {
            timervaluewatchdog.reset();
                while(!timervaluewatchdog.expired());
                if(3==uxBits)
                {
                    Storage::append("1:plottaskstatus.txt", "Success", 4, 0);
                }else if(2 == uxBits)
                {

                    Storage::append("1:plottaskstatus.txt", "producer", 4, 0);
                }else if(1==uxBits)
                {
                    Storage::append("1:plottaskstatus.txt", "consumer", 4, 0);
                }
                else
                {
                    Storage::append("1:plottaskstatus.txt", "Failure", 4, 0);
                }
               return true;
        }
};
class cpuUtilization : public scheduler_task
{

    public:
        cpuUtilization(uint8_t priority):
            scheduler_task("cpuUtilization",2048,priority)
    {


    }
        bool init()
        {

            return true;
        }
        bool run(void *p)
        {  char buf[512];
           cpuUsageinfo.reset();
           while(cpuUsageinfo.expired());
           sys_get_mem_info_str(buf);
           Storage::append("1:cpu.txt",buf,512, 0);
           return true;
        }
};
int maina()
{
    myeventgroup = xEventGroupCreate();
    scheduler_add_task(new lightsensorconsumer(PRIORITY_MEDIUM));
    scheduler_add_task(new lightsensorproducer(PRIORITY_MEDIUM));
    scheduler_add_task(new cpuUtilization(PRIORITY_MEDIUM));
    scheduler_add_task(new lightwatchdog(PRIORITY_HIGH));
    scheduler_add_task(new terminalTask(PRIORITY_HIGH));
    scheduler_start();

    return true;
}
