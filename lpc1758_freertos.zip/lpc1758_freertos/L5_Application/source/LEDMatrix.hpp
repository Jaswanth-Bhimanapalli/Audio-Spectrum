/*
 * LEDMatrix.hpp
 *
 *  Created on: May 13, 2016
 *      Author: Sucharitha
 */

#ifndef L5_APPLICATION_SOURCE_LEDMATRIX_HPP_
#define L5_APPLICATION_SOURCE_LEDMATRIX_HPP_


void displayLED(int count ,double value);
void DisplayLEDZero();
void i2cLEDinit();



#endif /* L5_APPLICATION_SOURCE_LEDMATRIX_HPP_ */
